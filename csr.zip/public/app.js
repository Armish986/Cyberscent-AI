(() => {
  "use strict";

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const escapeHtml = (str) =>
    String(str).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  /* ---------------- Session stats ---------------- */
  const stats = { scans: 0, threats: 0 };
  const bumpScan = (threat = false) => {
    stats.scans += 1;
    if (threat) stats.threats += 1;
    $("#stat-scans").textContent = stats.scans;
    $("#stat-threats").textContent = stats.threats;
  };

  /* ---------------- Active nav on scroll ---------------- */
  const navLinks = $$(".nav-link");
  const setActive = (id) => navLinks.forEach((l) => {
    const isActive = l.dataset.section === id;
    l.classList.toggle("active", isActive);
    if (isActive) l.setAttribute("aria-current", "page");
    else l.removeAttribute("aria-current");
  });
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((e) => { if (e.isIntersecting) setActive(e.target.id); });
    },
    { rootMargin: "-45% 0px -50% 0px" }
  );
  navLinks.forEach((l) => {
    const target = document.getElementById(l.dataset.section);
    if (target) observer.observe(target);
  });

  /* ---------------- Global search -> jump to tool ---------------- */
  const searchMap = [
    { keys: ["password", "strength", "pass"], id: "password" },
    { keys: ["phish", "link", "url"], id: "phishing" },
    { keys: ["breach", "email", "leak", "pwned"], id: "breach" },
    { keys: ["tip", "daily", "advice"], id: "tips" },
    { keys: ["news", "feed", "threat"], id: "news" },
    { keys: ["quiz", "test", "question"], id: "quiz" },
  ];
  $("#global-search").addEventListener("keydown", (e) => {
    if (e.key !== "Enter" || e.nativeEvent?.isComposing || e.isComposing || e.keyCode === 229) return;
    const q = e.target.value.trim().toLowerCase();
    const hit = searchMap.find((m) => m.keys.some((k) => q.includes(k)));
    if (hit) document.getElementById(hit.id).scrollIntoView({ behavior: "smooth" });
  });

  /* ---------------- Password strength ---------------- */
  const COMMON = ["password", "123456", "12345678", "qwerty", "abc123", "111111", "letmein", "welcome", "admin", "iloveyou", "monkey", "dragon", "football", "baseball", "sunshine", "princess", "passw0rd", "password1", "123456789", "qwerty123"];
  const pwInput = $("#pw-input");
  const pwMeter = $("#pw-meter");
  const pwLabel = $("#pw-label");
  const LEVELS = [
    { label: "Very weak", tone: "danger" },
    { label: "Weak", tone: "danger" },
    { label: "Fair", tone: "warn" },
    { label: "Strong", tone: "primary" },
    { label: "Very strong", tone: "success" },
  ];

  const formatTime = (seconds) => {
    if (seconds < 1) return "Instantly";
    const units = [["century", 3153600000], ["year", 31536000], ["month", 2592000], ["day", 86400], ["hour", 3600], ["minute", 60], ["second", 1]];
    if (seconds > 3153600000 * 1000) return "Millennia+";
    for (const [name, size] of units) {
      if (seconds >= size) {
        const n = Math.floor(seconds / size);
        const plural = name === "century" ? "centuries" : name + "s";
        return `${n.toLocaleString()} ${n === 1 ? name : plural}`;
      }
    }
    return "Instantly";
  };

  const analyzePassword = (pw) => {
    const checks = {
      length: pw.length >= 12,
      upper: /[A-Z]/.test(pw),
      lower: /[a-z]/.test(pw),
      number: /\d/.test(pw),
      symbol: /[^A-Za-z0-9]/.test(pw),
      common: pw.length > 0 && !COMMON.includes(pw.toLowerCase()),
    };
    let pool = 0;
    if (checks.lower) pool += 26;
    if (checks.upper) pool += 26;
    if (checks.number) pool += 10;
    if (checks.symbol) pool += 33;
    let entropy = pw.length ? pw.length * Math.log2(pool || 1) : 0;
    if (/(.)\1{2,}/.test(pw)) entropy *= 0.75;
    if (/(abc|123|qwe|asd|xyz)/i.test(pw)) entropy *= 0.85;
    if (!checks.common) entropy = Math.min(entropy, 10);

    let score = 0;
    if (entropy >= 28) score = 1;
    if (entropy >= 45) score = 2;
    if (entropy >= 60) score = 3;
    if (entropy >= 80 && checks.length) score = 4;
    const seconds = Math.pow(2, entropy) / 1e10;
    return { checks, entropy: Math.round(entropy), score, seconds };
  };

  const renderPassword = () => {
    const pw = pwInput.value;
    const res = analyzePassword(pw);
    $$("#pw-checks li").forEach((li) => li.classList.toggle("ok", !!res.checks[li.dataset.check]));
    if (!pw) {
      pwMeter.dataset.score = "-1";
      pwMeter.setAttribute("aria-valuenow", "0");
      pwLabel.textContent = "Start typing";
      pwLabel.removeAttribute("data-tone");
      $("#pw-time").textContent = "—";
      $("#pw-entropy").textContent = "Entropy: 0 bits";
      return;
    }
    const level = LEVELS[res.score];
    pwMeter.dataset.score = res.score;
    pwMeter.setAttribute("aria-valuenow", String(res.score));
    pwLabel.textContent = level.label;
    pwLabel.dataset.tone = level.tone;
    $("#pw-time").textContent = formatTime(res.seconds);
    $("#pw-entropy").textContent = `Entropy: ${res.entropy} bits`;
    $("#stat-strength").textContent = level.label;
  };
  pwInput.addEventListener("input", renderPassword);

  $("#pw-toggle").addEventListener("click", (e) => {
    const btn = e.currentTarget;
    const show = pwInput.type === "password";
    pwInput.type = show ? "text" : "password";
    btn.setAttribute("aria-pressed", String(show));
    btn.setAttribute("aria-label", show ? "Hide password" : "Show password");
  });

  $("#pw-generate").addEventListener("click", () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*-_=+?";
    const arr = new Uint32Array(18);
    crypto.getRandomValues(arr);
    pwInput.value = Array.from(arr, (n) => chars[n % chars.length]).join("");
    pwInput.type = "text";
    $("#pw-toggle").setAttribute("aria-pressed", "true");
    renderPassword();
  });

  /* ---------------- Phishing detector ---------------- */
  const SUSPICIOUS_TLDS = ["xyz", "top", "tk", "ml", "ga", "cf", "gq", "zip", "mov", "click", "country", "work", "loan", "rest"];
  const BAIT_WORDS = ["login", "signin", "verify", "secure", "account", "update", "confirm", "banking", "wallet", "password", "suspend", "unlock", "billing"];
  const BRANDS = ["paypal", "google", "apple", "microsoft", "amazon", "netflix", "facebook", "instagram", "bank"];
  const SHORTENERS = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly", "cutt.ly"];

  const analyzeUrl = (raw) => {
    let input = raw.trim();
    if (!/^[a-z]+:\/\//i.test(input)) input = "http://" + input;
    let url;
    try { url = new URL(input); } catch { return null; }

    const host = url.hostname.toLowerCase();
    const full = url.href.toLowerCase();
    const flags = [];
    const good = [];
    let score = 0;
    const add = (pts, msg) => { score += pts; flags.push(msg); };

    if (url.protocol !== "https:") add(15, "Connection is not encrypted (no HTTPS)");
    else good.push("Uses encrypted HTTPS connection");
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) add(30, "Uses a raw IP address instead of a domain");
    if (raw.includes("@")) add(20, "Contains '@' which can hide the real destination");
    if (host.startsWith("xn--") || host.includes(".xn--")) add(25, "Punycode domain — possible lookalike characters");
    const tld = host.split(".").pop();
    if (SUSPICIOUS_TLDS.includes(tld)) add(15, `High-risk top-level domain (.${tld})`);
    if (host.split(".").length > 4) add(10, "Excessive number of subdomains");
    if ((host.match(/-/g) || []).length >= 2) add(10, "Multiple hyphens in domain name");
    if (full.length > 90) add(8, "Unusually long URL");
    if (SHORTENERS.includes(host)) add(15, "URL shortener hides the final destination");
    const bait = BAIT_WORDS.filter((w) => full.includes(w));
    if (bait.length) add(Math.min(bait.length * 8, 24), `Credential-bait keywords: ${bait.slice(0, 3).join(", ")}`);
    const leet = host.replace(/0/g, "o").replace(/1/g, "l").replace(/3/g, "e").replace(/5/g, "s");
    const brand = BRANDS.find((b) => leet.includes(b));
    if (brand) {
      const legit = host === `${brand}.com` || host.endsWith(`.${brand}.com`);
      if (!legit) add(25, `Impersonates "${brand}" on an unofficial domain`);
    }
    if (url.port && !["80", "443"].includes(url.port)) add(10, `Non-standard port :${url.port}`);

    score = Math.min(100, score);
    if (!flags.length) good.push("No common phishing patterns detected");
    return { host, score, flags, good };
  };

  const phishInput = $("#phish-input");
  $("#phish-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const value = phishInput.value;
    const resultEl = $("#phish-result");
    const emptyEl = $("#phish-empty");
    if (!value.trim()) { phishInput.focus(); return; }
    const res = analyzeUrl(value);
    if (!res) {
      resultEl.hidden = true;
      emptyEl.hidden = false;
      emptyEl.textContent = "That doesn't look like a valid URL. Try again.";
      return;
    }
    const tone = res.score >= 55 ? "danger" : res.score >= 25 ? "warn" : "success";
    const verdict = tone === "danger" ? "High risk — likely phishing" : tone === "warn" ? "Suspicious — proceed with caution" : "Likely safe";
    const gauge = $("#phish-gauge");
    gauge.style.setProperty("--value", res.score);
    gauge.dataset.tone = tone;
    $("#phish-score").textContent = res.score;
    const v = $("#phish-verdict");
    v.textContent = verdict;
    v.dataset.tone = tone;
    $("#phish-host").textContent = res.host;
    $("#phish-flags").innerHTML =
      res.flags.map((f) => `<li>${escapeHtml(f)}</li>`).join("") +
      res.good.map((g) => `<li class="good">${escapeHtml(g)}</li>`).join("");
    resultEl.hidden = false;
    emptyEl.hidden = true;
    bumpScan(tone !== "success");
  });
  $$("[data-sample]").forEach((btn) =>
    btn.addEventListener("click", () => {
      phishInput.value = btn.dataset.sample;
      $("#phish-form").requestSubmit();
    })
  );

  /* ---------------- Breach checker (simulated) ---------------- */
  const BREACHES = [
    { name: "SocialHub", date: "2024-03", data: ["Email", "Password", "Username"] },
    { name: "ShopNest", date: "2023-11", data: ["Email", "Address", "Phone"] },
    { name: "FitTrack", date: "2023-06", data: ["Email", "Password", "DOB"] },
    { name: "StreamBox", date: "2022-09", data: ["Email", "Payment hint"] },
    { name: "GameVault", date: "2021-12", data: ["Email", "Username", "IP"] },
    { name: "TravelMate", date: "2021-04", data: ["Email", "Passport no.", "Phone"] },
  ];
  const DISPOSABLE = ["mailinator.com", "10minutemail.com", "guerrillamail.com", "tempmail.com", "yopmail.com"];
  const hash = (s) => { let h = 5381; for (const c of s) h = ((h << 5) + h + c.charCodeAt(0)) >>> 0; return h; };

  const breachForm = $("#breach-form");
  const breachInput = $("#breach-input");
  const breachBtn = $("#breach-btn");
  const breachResult = $("#breach-result");
  const breachError = $("#breach-error");

  breachForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = breachInput.value.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
      breachError.textContent = "Please enter a valid email address.";
      breachInput.setAttribute("aria-invalid", "true");
      return;
    }
    breachError.textContent = "";
    breachInput.removeAttribute("aria-invalid");
    breachBtn.disabled = true;
    breachBtn.innerHTML = '<span class="spinner" aria-hidden="true"></span>Scanning';
    breachResult.innerHTML = '<p class="empty">Analyzing breach databases...</p>';

    setTimeout(() => {
      const h = hash(email);
      const domain = email.split("@")[1];
      const count = h % 4 === 0 ? 0 : (h % 3) + 1;
      const found = [];
      for (let i = 0; i < count; i++) found.push(BREACHES[(h >> (i * 3)) % BREACHES.length]);
      const unique = [...new Map(found.map((b) => [b.name, b])).values()];
      const disposable = DISPOSABLE.includes(domain);

      if (!unique.length) {
        breachResult.innerHTML = `
          <div class="breach-summary safe">
            <span class="stat-icon"><svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/></svg></span>
            <div><p><strong>Good news — no breaches found</strong></p><p class="muted small">${escapeHtml(email)} wasn't found in our breach index.</p></div>
          </div>
          <ul class="recs">${disposable ? "<li>This looks like a disposable email domain — avoid it for important accounts.</li>" : ""}<li>Keep using unique passwords and enable 2FA everywhere.</li></ul>`;
        bumpScan(false);
      } else {
        breachResult.innerHTML = `
          <div class="breach-summary danger">
            <span class="stat-icon"><svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/></svg></span>
            <div><p><strong>Found in ${unique.length} breach${unique.length > 1 ? "es" : ""}</strong></p><p class="muted small">${escapeHtml(email)} has been exposed.</p></div>
          </div>
          <ul class="breach-list">
            ${unique.map((b) => `
              <li class="breach-item">
                <div><h4>${b.name}</h4><div class="data">${b.data.map((d) => `<span>${d}</span>`).join("")}</div></div>
                <time datetime="${b.date}">${b.date}</time>
              </li>`).join("")}
          </ul>
          <ul class="recs">
            <li>Change passwords on affected services immediately.</li>
            <li>Enable two-factor authentication on your email account.</li>
            <li>Watch for phishing emails referencing these services.</li>
          </ul>`;
        bumpScan(true);
      }
      breachBtn.disabled = false;
      breachBtn.textContent = "Check email";
    }, 1100);
  });

  /* ---------------- Daily tips ---------------- */
  const TIPS = [
    { cat: "Passwords", title: "Use a password manager", text: "Let a reputable password manager generate and store a unique password for every account. You only need to remember one strong master passphrase." },
    { cat: "Authentication", title: "Turn on two-factor authentication", text: "Prefer authenticator apps or hardware keys over SMS codes. 2FA blocks the vast majority of automated account takeover attempts." },
    { cat: "Phishing", title: "Hover before you click", text: "Preview where a link really goes before clicking. If the domain doesn't exactly match the sender's official site, don't trust it." },
    { cat: "Updates", title: "Patch early, patch often", text: "Enable automatic updates for your OS, browser and apps. Most attacks exploit vulnerabilities that already have a fix available." },
    { cat: "Wi-Fi", title: "Be careful on public Wi-Fi", text: "Avoid logging into sensitive accounts on open networks. Use a trusted VPN or your phone's hotspot instead." },
    { cat: "Backups", title: "Follow the 3-2-1 backup rule", text: "Keep 3 copies of your data, on 2 different types of media, with 1 copy stored offline or off-site to survive ransomware." },
    { cat: "Privacy", title: "Review app permissions", text: "Audit which apps can access your location, camera, microphone and contacts. Revoke anything an app doesn't truly need." },
    { cat: "Social", title: "Limit what you overshare", text: "Pet names, birthdays and hometowns are common security answers. Keep personal details off public profiles." },
  ];
  const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0)) / 86400000);
  let tipIndex = dayOfYear % TIPS.length;
  const dotsEl = $("#tip-dots");
  dotsEl.innerHTML = TIPS.map(() => "<span></span>").join("");
  $("#tip-date").textContent = new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" });

  const renderTip = () => {
    const t = TIPS[tipIndex];
    $("#tip-category").textContent = t.cat;
    $("#tip-number").textContent = `#${String(tipIndex + 1).padStart(2, "0")}`;
    $("#tip-title").textContent = t.title;
    $("#tip-text").textContent = t.text;
    $$("span", dotsEl).forEach((d, i) => d.classList.toggle("active", i === tipIndex));
    const body = $(".tip-body");
    body.style.animation = "none";
    void body.offsetWidth;
    body.style.animation = "";
  };
  $("#tip-prev").addEventListener("click", () => { tipIndex = (tipIndex - 1 + TIPS.length) % TIPS.length; renderTip(); });
  $("#tip-next").addEventListener("click", () => { tipIndex = (tipIndex + 1) % TIPS.length; renderTip(); });
  renderTip();

  /* ---------------- News feed ---------------- */
  const NEWS = [
    { cat: "Ransomware", sev: "high", title: "Ransomware crews shift to data-theft-only extortion", summary: "Security researchers report more groups skipping encryption entirely and threatening to leak stolen files instead.", source: "Threat Intel Weekly", time: "2h ago", read: "4 min" },
    { cat: "Phishing", sev: "high", title: "QR-code phishing campaigns surge in corporate inboxes", summary: "Attackers embed malicious QR codes in PDFs to bypass link scanners and redirect victims to fake login pages.", source: "SecOps Digest", time: "5h ago", read: "3 min" },
    { cat: "Vulnerability", sev: "high", title: "Critical browser zero-day patched in emergency update", summary: "Users are urged to restart their browsers to apply a fix for a memory corruption flaw under active exploitation.", source: "Patch Tracker", time: "8h ago", read: "2 min" },
    { cat: "Privacy", sev: "low", title: "New guidance on limiting app tracking across devices", summary: "A practical breakdown of the privacy settings that matter most on modern phones, tablets and smart TVs.", source: "Privacy Matters", time: "1d ago", read: "6 min" },
    { cat: "AI Security", sev: "low", title: "Deepfake voice scams: how to verify urgent calls", summary: "Experts recommend family 'safe words' and call-back verification as AI voice cloning becomes cheaper.", source: "Cyberscent Research", time: "1d ago", read: "5 min" },
    { cat: "Data Breach", sev: "high", title: "Credential-stuffing wave targets streaming accounts", summary: "Reused passwords from older leaks are being tested at scale. Unique passwords and 2FA remain the best defense.", source: "Breach Monitor", time: "2d ago", read: "3 min" },
  ];
  const cats = ["All", ...new Set(NEWS.map((n) => n.cat))];
  const filtersEl = $("#news-filters");
  let activeCat = "All";
  filtersEl.innerHTML = cats.map((c) => `<button type="button" class="chip${c === "All" ? " active" : ""}" data-cat="${c}" aria-pressed="${c === "All"}">${c}</button>`).join("");

  const renderNews = () => {
    const items = NEWS.filter((n) => activeCat === "All" || n.cat === activeCat);
    $("#news-list").innerHTML = items.map((n) => `
      <li class="news-item">
        <div class="news-meta"><span class="news-cat" data-sev="${n.sev}">${n.cat}</span><span>${n.time}</span></div>
        <h3>${escapeHtml(n.title)}</h3>
        <p>${escapeHtml(n.summary)}</p>
        <div class="news-foot"><span>${escapeHtml(n.source)}</span><span>${n.read} read</span></div>
      </li>`).join("");
  };
  filtersEl.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-cat]");
    if (!btn) return;
    activeCat = btn.dataset.cat;
    $$(".chip", filtersEl).forEach((c) => {
      const on = c === btn;
      c.classList.toggle("active", on);
      c.setAttribute("aria-pressed", String(on));
    });
    renderNews();
  });
  renderNews();

  /* ---------------- Quiz ---------------- */
  const QUESTIONS = [
    { type: "mcq", q: "Which of these is the strongest password?", options: ["Password123!", "Tr0ub4dor", "correct-horse-battery-staple-92", "qwerty2026"], answer: 2, explain: "Long passphrases with multiple random words have far higher entropy than short, complex-looking passwords." },
    { type: "open", q: "Explain what phishing is and name one way to recognize a phishing email.", keywords: ["fake", "trick", "impersonat", "steal", "credential", "password", "link", "sender", "urgent", "spelling", "domain", "attachment", "pretend"], min: 3, model: "Phishing is a social-engineering attack where criminals impersonate a trusted party to trick you into revealing credentials or installing malware. Red flags include urgent language, mismatched sender domains, unexpected attachments and suspicious links." },
    { type: "mcq", q: "What does the 'S' in HTTPS stand for?", options: ["Simple", "Secure", "Server", "Signed"], answer: 1, explain: "HTTPS = HyperText Transfer Protocol Secure. It encrypts data in transit using TLS." },
    { type: "mcq", q: "Which 2FA method is generally considered the MOST secure?", options: ["SMS text codes", "Email codes", "Hardware security key", "Security questions"], answer: 2, explain: "Hardware keys (FIDO2/WebAuthn) are phishing-resistant because they verify the site's real domain." },
    { type: "open", q: "Why is reusing the same password across multiple sites dangerous?", keywords: ["breach", "leak", "one", "all", "other", "credential", "stuffing", "access", "compromise", "hack", "multiple", "every"], min: 3, model: "If one site is breached, attackers try the leaked email/password combo on many other services (credential stuffing). Reuse means a single leak can compromise every account." },
    { type: "mcq", q: "You get a text saying your bank account is locked with a link to unlock it. What should you do?", options: ["Click the link quickly", "Reply with your account number", "Contact the bank using its official app or number", "Forward it to friends"], answer: 2, explain: "Always verify through an official channel you already trust — never through links in unsolicited messages." },
    { type: "open", q: "What is ransomware, and what is one good way to protect against it?", keywords: ["encrypt", "lock", "files", "ransom", "pay", "backup", "update", "patch", "offline", "malware", "extort"], min: 3, model: "Ransomware is malware that encrypts or steals your files and demands payment for their return. Regular offline backups, prompt software updates and caution with attachments are key defenses." },
    { type: "mcq", q: "What is a VPN primarily used for?", options: ["Speeding up your internet", "Encrypting traffic between you and the VPN server", "Removing viruses", "Blocking all ads"], answer: 1, explain: "A VPN creates an encrypted tunnel to its server, protecting your traffic on untrusted networks like public Wi-Fi." },
  ];

  const stage = $("#quiz-stage");
  let mode = "mixed";
  let pool = [];
  let qi = 0;
  let score = 0;
  let best = 0;
  const KEYS = ["A", "B", "C", "D"];

  const startQuiz = () => {
    pool = QUESTIONS.filter((q) => mode === "mixed" || q.type === mode);
    qi = 0;
    score = 0;
    renderQuestion();
  };

  const updateProgress = () => {
    $("#quiz-count").textContent = `Question ${Math.min(qi + 1, pool.length)} of ${pool.length}`;
    $("#quiz-type").textContent = pool[qi] ? (pool[qi].type === "mcq" ? "Multiple choice" : "Open-ended") : "Complete";
    $("#quiz-score").textContent = score % 1 ? score.toFixed(1) : score;
    $("#quiz-bar").style.width = `${(qi / pool.length) * 100}%`;
  };

  const nextButton = (last) =>
    `<button type="button" class="btn btn-primary" id="quiz-next">${last ? "See results" : "Next question"}</button>`;

  const renderQuestion = () => {
    updateProgress();
    if (qi >= pool.length) return renderResults();
    const q = pool[qi];
    const last = qi === pool.length - 1;
    stage.style.animation = "none"; void stage.offsetWidth; stage.style.animation = "";

    if (q.type === "mcq") {
      stage.innerHTML = `
        <p class="quiz-q">${escapeHtml(q.q)}</p>
        <div class="options" role="group" aria-label="Answer options">
          ${q.options.map((o, i) => `<button type="button" class="option" data-i="${i}"><span class="option-key">${KEYS[i]}</span><span>${escapeHtml(o)}</span></button>`).join("")}
        </div>
        <div id="quiz-feedback" aria-live="polite"></div>`;
      $$(".option", stage).forEach((btn) =>
        btn.addEventListener("click", () => {
          const pick = Number(btn.dataset.i);
          const correct = pick === q.answer;
          if (correct) score += 1;
          $$(".option", stage).forEach((b, i) => {
            b.disabled = true;
            if (i === q.answer) b.classList.add("correct");
            else if (i === pick) b.classList.add("wrong");
          });
          $("#quiz-feedback").innerHTML = `
            <div class="feedback ${correct ? "good" : "bad"}"><strong>${correct ? "Correct!" : "Not quite."}</strong><span class="muted">${escapeHtml(q.explain)}</span></div>
            <div class="quiz-actions" style="margin-top:14px"><span></span>${nextButton(last)}</div>`;
          $("#quiz-score").textContent = score % 1 ? score.toFixed(1) : score;
          $("#quiz-next").addEventListener("click", () => { qi++; renderQuestion(); });
          $("#quiz-next").focus();
        })
      );
    } else {
      stage.innerHTML = `
        <p class="quiz-q">${escapeHtml(q.q)}</p>
        <label for="open-answer" class="sr-only">Your answer</label>
        <textarea id="open-answer" class="input" placeholder="Write your answer in your own words..."></textarea>
        <div class="quiz-actions">
          <span class="muted small" id="open-count">0 words</span>
          <button type="button" class="btn btn-primary" id="open-submit">Submit answer</button>
        </div>
        <div id="quiz-feedback" aria-live="polite"></div>`;
      const ta = $("#open-answer");
      ta.addEventListener("input", () => {
        const words = ta.value.trim().split(/\s+/).filter(Boolean).length;
        $("#open-count").textContent = `${words} word${words === 1 ? "" : "s"}`;
      });
      $("#open-submit").addEventListener("click", () => {
        const text = ta.value.toLowerCase();
        if (text.trim().split(/\s+/).filter(Boolean).length < 4) {
          $("#quiz-feedback").innerHTML = '<div class="feedback partial"><strong>Add a bit more detail</strong><span class="muted">Write at least a sentence so we can evaluate your answer.</span></div>';
          return;
        }
        const hits = q.keywords.filter((k) => text.includes(k)).length;
        const level = hits >= q.min ? "good" : hits >= Math.ceil(q.min / 2) ? "partial" : "bad";
        const pts = level === "good" ? 1 : level === "partial" ? 0.5 : 0;
        score += pts;
        ta.disabled = true;
        $("#open-submit").remove();
        const title = level === "good" ? "Great answer!" : level === "partial" ? "Partially correct" : "Needs improvement";
        $("#quiz-feedback").innerHTML = `
          <div class="feedback ${level}"><strong>${title} (+${pts})</strong><span class="muted"><strong style="color:#fff">Model answer:</strong> ${escapeHtml(q.model)}</span></div>
          <div class="quiz-actions" style="margin-top:14px"><span></span>${nextButton(last)}</div>`;
        $("#quiz-score").textContent = score % 1 ? score.toFixed(1) : score;
        $("#quiz-next").addEventListener("click", () => { qi++; renderQuestion(); });
        $("#quiz-next").focus();
      });
    }
  };

  const renderResults = () => {
    const pct = Math.round((score / pool.length) * 100);
    best = Math.max(best, pct);
    $("#stat-quiz").textContent = `${best}%`;
    const newScore = Math.min(100, 82 + Math.round(best / 10));
    $("#sidebar-score").textContent = newScore;
    $(".mini-bar span").style.width = `${newScore}%`;
    $("#quiz-bar").style.width = "100%";
    const msg = pct >= 80 ? "Excellent — you're a security pro!" : pct >= 50 ? "Solid effort. Review the tips to level up." : "Keep learning — check out the daily tips.";
    stage.innerHTML = `
      <div class="quiz-done">
        <div class="ring" style="--value:${pct}"><span>${pct}%</span><small>Score</small></div>
        <p class="quiz-q">${msg}</p>
        <p class="muted small">You scored ${score % 1 ? score.toFixed(1) : score} out of ${pool.length}.</p>
        <button type="button" class="btn btn-primary" id="quiz-restart">Retake quiz</button>
      </div>`;
    $("#quiz-restart").addEventListener("click", startQuiz);
  };

  $("#quiz-modes").addEventListener("click", (e) => {
    const btn = e.target.closest("[data-mode]");
    if (!btn) return;
    mode = btn.dataset.mode;
    $$("#quiz-modes .chip").forEach((c) => {
      const on = c === btn;
      c.classList.toggle("active", on);
      c.setAttribute("aria-pressed", String(on));
    });
    startQuiz();
  });
  startQuiz();
})();
